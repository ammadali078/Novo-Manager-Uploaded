//
//  ContactViewController.swift
//  E-detailer
//
//  Created by Ammad on 12/31/04.
//  Copyright © 2004 Ammad. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import ObjectMapper

class ContactViewController: UIViewController {
    
    @IBOutlet weak var contactListLayout: UIView!
    
    @IBOutlet weak var contactListCollectionView: UICollectionView!
    
     var contactListDataSource: ContactListCell!
    
    @IBAction func BTNSinc(_ sender: Any) {
        callApi()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        contactListDataSource = ContactListCell()
        contactListCollectionView.dataSource = contactListDataSource
        
        contactListDataSource.onClick = {(selectedModel: ContactResult) in
            let alert = UIAlertController(title: "Attendance", message: "Are you sure, you want to mark attendance at " + selectedModel.dESCR! + " ?", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: {_ in
                alert.dismiss(animated: false, completion: nil)
                
            }))
            alert.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.cancel, handler: {_ in
                alert.dismiss(animated: false, completion: nil)
            }))
            self.present(alert, animated: true, completion: nil)
        }
        
        callApi()
    }
    
    
    
    func callApi() {
        Alamofire.request(Constants.ContactApi, method: .get, encoding: JSONEncoding.default, headers: nil)
            .responseString(completionHandler: (completionHandler: {(response) in
                // On Response
                
                //On Dialog Close
                if (response.error != nil) {
                    CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: (response.error?.localizedDescription)!)
                    return
                }
                let contactModel = Mapper<ContactModel>().map(JSONString: response.value!) //JSON to model
                if contactModel != nil {
                    if (contactModel?.success)! {
                        
                        self.contactListDataSource.setItems(items: contactModel?.result)
                        self.contactListCollectionView.reloadData()
                        
                    } else {
                        CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: (contactModel?.error!)!)
                    }
                } else {
                    CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: "Empty Response is coming from server")
                }
            }))

    }
    
}
