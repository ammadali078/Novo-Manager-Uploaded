//
//  Constants.swift
//  E-detailer
//
//  Created by Ammad on 8/3/18.
//  Copyright © 2018 Ammad. All rights reserved.
//

import Foundation

class Constants {
    static let BaseUrl = "http://atco.digitrends.pk/"
    static let LoginApi = BaseUrl + "Account/Login"
    static let ContentApi = BaseUrl + "Account/getcontent"
    static let ContactApi = BaseUrl + "webapi/GetAllContactPoints"
    
    static let LOGIN_RESULT = "login_result"
    static let EMP_ID = "EMP_ID"
}
