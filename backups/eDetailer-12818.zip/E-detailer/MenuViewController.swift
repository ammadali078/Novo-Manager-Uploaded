//
//  MenuViewController.swift
//  E-detailer
//
//  Created by Ammad on 8/4/18.
//  Copyright © 2018 Ammad. All rights reserved.
//

import Foundation
import UIKit

class MenuViewController: UIViewController {
    
    @IBOutlet weak var mEmpIdLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mEmpIdLabel.text = "EMP ID: " + CommonUtils.getJsonFromUserDefaults(forKey: Constants.EMP_ID)
    }
    
    
   @IBAction func BTNProduct(_ sender: Any) {
        
        self.performSegue(withIdentifier: "SendToProductScreen", sender: self)
    }
    
        
    @IBAction func BTNStatistics(_ sender: Any) {
        
        self.performSegue(withIdentifier: "SendToStatisticsScreen", sender: self)
    }
    
    
    
    @IBAction func BTNEXP(_ sender: Any) {
        
        self.performSegue(withIdentifier: "SendToEXPScreen", sender: self)
    }
  
    @IBAction func BTNAVI(_ sender: Any) {
        
        self.performSegue(withIdentifier:
        "SendToAVIScreen", sender: self)
    }
        
   
    @IBAction func BTNPDF(_ sender: Any) {
        
        self.performSegue(withIdentifier:
            "SendToPDFScreen", sender: self)
    }
   
    @IBAction func BTNKnowledge(_ sender: Any) {
        
        
        self.performSegue(withIdentifier:
            "SendToKnowledgeScreen", sender: self)
        
    }
    
    
    @IBAction func BTNGeneral(_ sender: Any) {
        
        self.performSegue(withIdentifier:
            "SendToGeneralScreen", sender: self)
        
    }
    
    
    @IBAction func BTNContact(_ sender: Any) {
        
        self.performSegue(withIdentifier:
            "SendToContactScreen", sender: self)
        
    }
    
    
    
    
}



