//
//  CommonUtils.swift
//  E-detailer
//
//  Created by Ammad on 8/3/18.
//  Copyright © 2018 Ammad. All rights reserved.
//

import Foundation
import UIKit


class CommonUtils {

    static func showMsgDialog(showingPopupOn controller: UIViewController, withTitle title:String, withMessage msg: String) {
        let alert = UIAlertController(title: title, message: msg, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {_ in
            alert.dismiss(animated: false, completion: nil)
        }))
        
        controller.present(alert, animated: true, completion: nil)
    }
    
    static func saveJsonToUserDefaults(forKey key: String, withJson json: String) {
        UserDefaults.standard.set(json, forKey: key);
    }
    
    static func getJsonFromUserDefaults(forKey key: String) -> String {
        return UserDefaults.standard.string(forKey: key)!;
    }
    
    static func log(value: String){
        print(value)
    }
}
