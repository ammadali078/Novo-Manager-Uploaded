//
//  ProductViewController.swift
//  E-detailer
//
//  Created by Ammad on 8/6/18.
//  Copyright © 2018 Ammad. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import ObjectMapper

class ProductViewController:  UIViewController{
var indicator: UIActivityIndicatorView!
var activitiyViewController: ActivityViewController!
    
    @IBOutlet weak var downloadableContentLayout: UIView!
    
    @IBOutlet weak var downloadableCollectionView: UICollectionView!
    
    var downloadableContentDataSource: ProductDownloadContentCell!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        activitiyViewController = ActivityViewController(message: "Loading...")
        
        downloadableContentDataSource = ProductDownloadContentCell()
        downloadableCollectionView.dataSource = downloadableContentDataSource
    }
    
    @IBAction func BTNSync(_ sender: Any) {
        activitiyViewController.show(existingUiViewController: self)
        // Api Executed
        Alamofire.request(Constants.ContentApi, method: .get, encoding: JSONEncoding.default, headers: nil)
            .responseString(completionHandler: (completionHandler: {(response) in
                // On Response
                self.activitiyViewController.dismiss(animated: false, completion: {() in
                    
                //On Dialog Close
                if (response.error != nil) {
                        CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: (response.error?.localizedDescription)!)
                        return
                    }
                    let contentModel = Mapper<ContentModel>().map(JSONString: response.value!) //JSON to model
                    if contentModel != nil {
                        if (contentModel?.success)! {
                            
                            self.downloadableContentLayout.isHidden = false
                            self.downloadableContentDataSource.setItems(items: contentModel?.result)
                            self.downloadableCollectionView.reloadData()
                            
                        } else {
                            CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: (contentModel?.error!)!)
                        }
                    } else {
                        CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: "Empty Response is coming from server")
                    }
                    
                    
                })
            }))
    
    }
    @IBAction func BTNcloseContent(_ sender: Any) {
        
        self.downloadableContentLayout.isHidden = true
        }
}
