//
//  LoginViewController.swift
//  E-detailer
//
//  Created by Ammad on 8/1/18.
//  Copyright © 2018 Ammad. All rights reserved.
//

import UIKit
import Alamofire
import ObjectMapper

class LoginViewController: UIViewController {
   
    @IBOutlet weak var UserEmail: UITextField!
    @IBOutlet weak var UserPassword: UITextField!
    var indicator: UIActivityIndicatorView!
    var activitiyViewController: ActivityViewController!
    
    
    @IBAction func onLogin(_ sender: Any) {
        let providedEmailAddress = UserEmail.text
        let providedPassword = UserPassword.text
        if providedEmailAddress == "" {
            CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: "Please Enter the Email")
            return
        }
        
        if providedPassword == "" {
            CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: "Please Enter the Password")
            return
        }
        
        
        //!---------- Api Call
        var params = Dictionary<String, String>()

        params["team_id"] = providedEmailAddress;
        params["team_password"] = providedPassword;
        
        params["RmemberMe"] = "true";
        params["mac_address"] = "";
        
        
        activitiyViewController.show(existingUiViewController: self)
        
        // Api Executed
        Alamofire.request(Constants.LoginApi, method: .post, parameters: params, encoding: JSONEncoding.default, headers: nil)
            .responseString(completionHandler: (completionHandler: {(response) in
                // On Response
                self.activitiyViewController.dismiss(animated: false, completion: {() in
                    
                    //On Dialog Close
                    if (response.error != nil) {
                        CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: (response.error?.localizedDescription)!)
                        return
                    }
                    
                    let loginModel = Mapper<LoginModel>().map(JSONString: response.value!) //JSON to model
                    
                    if loginModel != nil {
                        
                        if (loginModel?.success)! {
                            
                            let r = Mapper<Result>().toJSONString((loginModel?.result)!, prettyPrint: false); // model to json
                            
                            CommonUtils.saveJsonToUserDefaults(forKey: Constants.LOGIN_RESULT, withJson: r!)
                            
                            CommonUtils.saveJsonToUserDefaults(forKey: Constants.EMP_ID, withJson: (loginModel?.result?.emp_id)!);
                            self.performSegue(withIdentifier: "Sendtomainscreen", sender: nil)
                            //dismiss(animated: false, completion: nil)
                            
                        } else {
                            CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: (loginModel?.error!)!)
                        }
                    } else {
                        CommonUtils.showMsgDialog(showingPopupOn: self, withTitle: "Error", withMessage: "Empty Response is coming from server")
                    }
                })
            }))
    }

    override func viewDidLoad() {
        super.viewDidLoad()
      activitiyViewController = ActivityViewController(message: "Loading...")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
